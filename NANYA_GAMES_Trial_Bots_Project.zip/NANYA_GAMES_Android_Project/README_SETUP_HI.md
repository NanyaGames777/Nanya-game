# NANYA GAMES — 4-player Android starter

## Updated features
- Host selects match duration from **3:00 to 10:00** in one-minute steps.
- Cartoon/chibi-style characters and colourful collectible power-ups.
- Match timer and shrinking danger zone.
- Power-ups: Medkit (+35 HP), Shield (9 sec / half damage), Speed (9 sec), Rapid Fire (9 sec).
- Android Studio source and GitHub Actions workflow for cloud APK build.

## Important status
This is an **early prototype/source project, not a finished secure online game and not an APK**. Firebase configuration is required. Full authoritative multiplayer combat, reliable cross-device bullets/hit validation, server-side damage, anti-cheat, reconnect, room cleanup and production security still need development. Do not publish with permissive test database rules.

## Firebase setup
1. Create a project at https://console.firebase.google.com/
2. Enable Authentication → Sign-in method → Anonymous.
3. Create Realtime Database.
4. Register a Web app in Firebase project settings.
5. Copy `apiKey`, `authDomain`, `databaseURL`, `projectId`, and `appId` into `app/src/main/assets/index.html` at `firebaseConfig`.
6. Implement secure database rules and server-authoritative damage validation before public release.

## Build APK using only a phone
1. Create a GitHub account and a new repository.
2. Upload all files from this ZIP (including the hidden `.github` folder).
3. Open repository → Actions → **Build NANYA GAMES APK** → Run workflow.
4. Download the `NANYA-GAMES-debug-apk` artifact from the completed run. It contains `app-debug.apk`.

A signed release APK needs additional signing configuration.


## Version 4: Intro Rap aur 4 Characters
- Opening screen par original English rap lines aur generated beat hai. Android WebView/browser autoplay restrictions ki wajah se pehli baar user ko TAP TO PLAY dabana pad sakta hai.
- Lobby mein Rookie, Ninja, Royal aur Cyborg characters select kiye ja sakte hain. Character choice player record mein save hoti hai.
- Rap voice device ke English text-to-speech engine par depend karti hai; agar TTS available na ho to synthesized beat phir bhi chalega.


## Version 5: Special NANYA Fighter
- 5th selectable fighter NANYA add hai. Avatar user ke supplied portrait se inspired hai: dark side-swept hair, glasses, moustache, white shirt and dark blazer, stylized to fit the game's cartoon arena.
- In-game name NANYA ke saath blue verified-style checkmark draw hota hai. Yeh game ka decorative badge hai, Instagram/Meta verification nahi.
- Yeh stylized approximation hai, exact photorealistic face scan nahi.
\n\n## V6 Update (11 Nov 2026)\n- Added a home screen inspired by the supplied NANYA GAMES reference image.\n- Added NANYA profile panel, five fighter tiles, Battle Royale / Custom Room buttons, and 3:00–10:00 match-time selector.\n- Added the supplied Firebase Web config and Realtime Database URL.\n- The supplied NANYA portrait crop is used in the home screen.\n\nIMPORTANT: Before online play, enable Anonymous Authentication and configure Realtime Database security rules. Current combat/network logic is still prototype-level and is not production-secure or fully tested for reliable 4-player multiplayer. GitHub Actions builds a debug APK only; it does not publish a public download link automatically.\n